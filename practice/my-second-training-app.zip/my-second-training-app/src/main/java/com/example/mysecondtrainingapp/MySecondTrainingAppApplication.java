package com.example.mysecondtrainingapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MySecondTrainingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MySecondTrainingAppApplication.class, args);
	}

}
