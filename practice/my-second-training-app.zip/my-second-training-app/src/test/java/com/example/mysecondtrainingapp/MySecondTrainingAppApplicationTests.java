package com.example.mysecondtrainingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySecondTrainingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
